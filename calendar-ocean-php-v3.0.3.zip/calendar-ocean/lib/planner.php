<?php
/*
 * 行程、紀念日、天氣地點：存在伺服器上的 data/planner.json。
 * 讀寫時用檔案鎖，避免兩個請求同時寫入把資料弄壞。
 */

function planner_file(): string
{
    return DATA_DIR . '/planner.json';
}

function planner_empty(): array
{
    return ['events' => [], 'annivs' => [], 'town' => null];
}

function planner_read(): array
{
    $file = planner_file();
    if (!is_file($file)) return planner_empty();
    $fp = fopen($file, 'rb');
    if (!$fp) return planner_empty();
    flock($fp, LOCK_SH);
    $raw = stream_get_contents($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    $data = json_decode($raw ?: '', true);
    return is_array($data) ? array_merge(planner_empty(), $data) : planner_empty();
}

/** 在檔案鎖之內讀出資料、交給 $fn 修改、再寫回去 */
function planner_update(callable $fn): array
{
    $file = planner_file();
    $fp = fopen($file, 'c+b');
    if (!$fp) {
        throw new RuntimeException('無法寫入 data/planner.json，請確認 data 資料夾可以寫入');
    }
    flock($fp, LOCK_EX);
    $raw = stream_get_contents($fp);
    $data = json_decode($raw ?: '', true);
    $data = is_array($data) ? array_merge(planner_empty(), $data) : planner_empty();
    $data = $fn($data);
    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    return $data;
}

function new_id(): string
{
    return base_convert((string)time(), 10, 36) . bin2hex(random_bytes(3));
}

function events_on(array $planner, string $ymd): array
{
    $list = array_values(array_filter($planner['events'], fn($e) => ($e['date'] ?? '') === $ymd));
    $key = fn($e) => ($e['time'] ?? '') !== '' ? $e['time'] : '99';
    usort($list, fn($a, $b) => strcmp($key($a), $key($b)));
    return array_map(fn($e) => ['id' => $e['id'], 'time' => $e['time'] ?? '', 'title' => $e['title']], $list);
}

function annivs_on(array $planner, int $n): array
{
    [$y, $m, $d] = civil_from_days($n);
    $lu = lunar_of($n);
    $out = [];
    foreach ($planner['annivs'] as $a) {
        $year = $a['year'] ?? null;
        if (!empty($a['lunar'])) {
            $hit = !$lu['leap'] && $lu['m'] === (int)$a['m'] && $lu['d'] === (int)$a['d'] && (!$year || $lu['ry'] >= $year);
            $cy = $lu['ry'];
        } else {
            $hit = (int)$a['m'] === $m && (int)$a['d'] === $d && (!$year || $y >= $year);
            $cy = $y;
        }
        if (!$hit) continue;
        if ($year) {
            $k = $cy - $year;
            $label = $k > 0 ? "{$a['title']}（第 {$k} 週年）" : "{$a['title']}（當年）";
        } else {
            $label = $a['title'];
        }
        $out[] = ['id' => $a['id'], 'title' => $a['title'], 'label' => $label, 'lunar' => !empty($a['lunar'])];
    }
    return $out;
}

/** 每日學習：依日期輪替，同一天看到的內容固定 */
function learn_of(int $n): array
{
    $L = load_json_data('learn.json');
    $en = $L['en'];
    $code = $L['code'];
    $ie = (($n % count($en)) + count($en)) % count($en);
    $ic = ((($n * 7) % count($code)) + count($code)) % count($code);
    return ['en' => $en[$ie], 'code' => $code[$ic]];
}

function seafood_in_month(int $m): array
{
    return array_values(array_filter(load_json_data('seafood.json'), fn($f) => in_array($m, $f['months'], true)));
}

/** 一個月的完整資料，交給頁面直接畫出來 */
function month_payload(int $y, int $m, ?array $planner = null): array
{
    $planner = $planner ?? planner_read();
    $first = days_from_civil($y, $m, 1);
    $len = days_in_month($y, $m);
    $a = lunar_of($first);
    $b = lunar_of($first + $len - 1);
    $mid = lunar_of($first + 14);
    $days = [];
    for ($i = 0; $i < $len; $i++) {
        $n = $first + $i;
        $f = day_info($n);
        $lu = $f['lu'];
        $days[] = [
            'd' => $i + 1,
            'dow' => weekday_of($n),
            'date' => ymd_of($n),
            'lunar' => $lu + [
                'text' => lunar_text($lu),
                'monthName' => lunar_month_name($lu),
                'dayName' => lunar_day_name($lu['d']),
                'ganzhi' => ganzhi($lu['ry']),
            ],
            'term' => $f['term'],
            'fests' => $f['fests'],
            'offNames' => $f['offNames'],
            'work' => $f['status']['work'],
            'off' => $f['off'],
            'src' => $f['status']['src'],
            'sp' => $f['sp'],
            'run' => $f['run'],
            'events' => events_on($planner, ymd_of($n)),
            'annivs' => annivs_on($planner, $n),
            'learn' => learn_of($n),
        ];
    }
    return [
        'y' => $y,
        'm' => $m,
        'rocYear' => $y - 1911,
        'firstDow' => weekday_of($first),
        'lunarRange' => '農曆 ' . lunar_text($a) . ' 至 ' . lunar_text($b) . '｜' . ganzhi($mid['ry']) . '年（' . zodiac($mid['ry']) . '）',
        'fish' => array_column(seafood_in_month($m), 'name'),
        'days' => $days,
    ];
}
