<?php
/*
 * 萬年曆的計算：農曆、二十四節氣、國定假日、補假、連假。
 * 只用 PHP 內建的數學與字串函式，不需要另外開啟 intl、calendar、mbstring 等擴充功能，XAMPP 預設就能跑。
 * 日期一律換成「從 1970-01-01 起算的天數」來計算，避免時區與夏令時間的問題。
 */

const CAL_MIN_YEAR = 1901;
const CAL_MAX_YEAR = 2099;

const WEEKDAY_NAMES = ['日', '一', '二', '三', '四', '五', '六'];
const LUNAR_MONTH_NAMES = ['正月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'];
const CN_NUM = ['', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十'];
const SOLAR_TERMS = ['小寒', '大寒', '立春', '雨水', '驚蟄', '春分', '清明', '穀雨', '立夏', '小滿', '芒種', '夏至',
    '小暑', '大暑', '立秋', '處暑', '白露', '秋分', '寒露', '霜降', '立冬', '小雪', '大雪', '冬至'];

/* ---------- 日期 ⇄ 天數 ---------- */

function days_from_civil(int $y, int $m, int $d): int
{
    $y -= $m <= 2 ? 1 : 0;
    $era = intdiv($y >= 0 ? $y : $y - 399, 400);
    $yoe = $y - $era * 400;
    $doy = intdiv(153 * ($m + ($m > 2 ? -3 : 9)) + 2, 5) + $d - 1;
    $doe = $yoe * 365 + intdiv($yoe, 4) - intdiv($yoe, 100) + $doy;
    return $era * 146097 + $doe - 719468;
}

function civil_from_days(int $z): array
{
    $z += 719468;
    $era = intdiv($z >= 0 ? $z : $z - 146096, 146097);
    $doe = $z - $era * 146097;
    $yoe = intdiv($doe - intdiv($doe, 1460) + intdiv($doe, 36524) - intdiv($doe, 146096), 365);
    $y = $yoe + $era * 400;
    $doy = $doe - (365 * $yoe + intdiv($yoe, 4) - intdiv($yoe, 100));
    $mp = intdiv(5 * $doy + 2, 153);
    $d = $doy - intdiv(153 * $mp + 2, 5) + 1;
    $m = $mp + ($mp < 10 ? 3 : -9);
    return [$y + ($m <= 2 ? 1 : 0), $m, $d];
}

/** 星期幾，0 = 星期日 */
function weekday_of(int $n): int
{
    return (($n + 4) % 7 + 7) % 7;
}

function days_in_month(int $y, int $m): int
{
    return $m === 12 ? 31 : days_from_civil($y, $m + 1, 1) - days_from_civil($y, $m, 1);
}

function ymd_of(int $n): string
{
    [$y, $m, $d] = civil_from_days($n);
    return sprintf('%04d-%02d-%02d', $y, $m, $d);
}

function pad2(int $n): string
{
    return sprintf('%02d', $n);
}

/* ---------- 資料檔 ---------- */

function load_json_data(string $file)
{
    static $cache = [];
    if (!isset($cache[$file])) {
        $raw = @file_get_contents(DATA_DIR . '/' . $file);
        if ($raw === false) {
            throw new RuntimeException("找不到資料檔 data/$file");
        }
        $cache[$file] = json_decode($raw, true);
    }
    return $cache[$file];
}

/* ---------- 農曆 ---------- */

/**
 * 農曆年表（data/lunar_table.json）：每個農曆年的正月初一日期，以及各月（含閏月）的天數。
 * 表格由天文曆算資料產生，涵蓋農曆 1899–2100 年。
 */
function lunar_years(): array
{
    static $list = null;
    if ($list === null) {
        $list = [];
        foreach (load_json_data('lunar_table.json') as $ry => $row) {
            [$y, $m, $d] = array_map('intval', explode('-', $row['start']));
            $list[] = ['ry' => (int)$ry, 'start' => days_from_civil($y, $m, $d), 'months' => $row['months']];
        }
        usort($list, fn($a, $b) => $a['start'] <=> $b['start']);
    }
    return $list;
}

/** 國曆日（天數）→ 農曆：['ry' => 農曆年, 'm' => 月, 'leap' => 是否閏月, 'd' => 日] */
function lunar_of(int $n): array
{
    static $cache = [];
    if (isset($cache[$n])) {
        return $cache[$n];
    }
    $years = lunar_years();
    $lo = 0;
    $hi = count($years) - 1;
    if ($n < $years[0]['start']) {
        throw new RangeException('日期超出農曆資料範圍');
    }
    while ($lo < $hi) {
        $mid = intdiv($lo + $hi + 1, 2);
        if ($years[$mid]['start'] <= $n) {
            $lo = $mid;
        } else {
            $hi = $mid - 1;
        }
    }
    $row = $years[$lo];
    $off = $n - $row['start'];
    foreach ($row['months'] as [$m, $leap, $len]) {
        if ($off < $len) {
            return $cache[$n] = ['ry' => $row['ry'], 'm' => (int)$m, 'leap' => (bool)$leap, 'd' => $off + 1];
        }
        $off -= $len;
    }
    throw new RangeException('日期超出農曆資料範圍');
}

function lunar_day_name(int $n): string
{
    if ($n <= 10) return '初' . CN_NUM[$n];
    if ($n < 20) return '十' . CN_NUM[$n - 10];
    if ($n === 20) return '二十';
    if ($n < 30) return '廿' . CN_NUM[$n - 20];
    return '三十';
}

function lunar_month_name(array $lu): string
{
    return ($lu['leap'] ? '閏' : '') . LUNAR_MONTH_NAMES[$lu['m'] - 1];
}

function lunar_text(array $lu): string
{
    return lunar_month_name($lu) . lunar_day_name($lu['d']);
}

function ganzhi(int $ry): string
{
    $stems = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];
    $branches = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];
    return $stems[(($ry - 4) % 10 + 10) % 10] . $branches[(($ry - 4) % 12 + 12) % 12];
}

function zodiac(int $ry): string
{
    $z = ['鼠', '牛', '虎', '兔', '龍', '蛇', '馬', '羊', '猴', '雞', '狗', '豬'];
    return $z[(($ry - 4) % 12 + 12) % 12];
}

/* ---------- 二十四節氣：以太陽視黃經計算（Meeus 低精度公式），換算為台北時間的日期 ---------- */

function sun_longitude(float $jd): float
{
    $t = ($jd - 2451545) / 36525;
    $r = M_PI / 180;
    $L0 = 280.46646 + 36000.76983 * $t + 0.0003032 * $t * $t;
    $M = (357.52911 + 35999.05029 * $t - 0.0001537 * $t * $t) * $r;
    $C = (1.914602 - 0.004817 * $t - 0.000014 * $t * $t) * sin($M)
        + (0.019993 - 0.000101 * $t) * sin(2 * $M) + 0.000289 * sin(3 * $M);
    $om = (125.04 - 1934.136 * $t) * $r;
    return fmod(fmod($L0 + $C - 0.00569 - 0.00478 * sin($om), 360) + 360, 360);
}

/** 一整年的節氣，鍵為「月-日」 */
function solar_terms(int $y): array
{
    static $cache = [];
    if (isset($cache[$y])) {
        return $cache[$y];
    }
    $map = [];
    for ($i = 0; $i < 24; $i++) {
        $ang = (285 + 15 * $i) % 360;
        $jd = days_from_civil($y, 1, 6) + 2440587.5 + $i * 15.22;
        for ($k = 0; $k < 8; $k++) {
            $diff = fmod(fmod($ang - sun_longitude($jd), 360) + 540, 360) - 180;
            $jd += $diff * 365.2422 / 360;
        }
        $days = ($jd - 2440587.5) - 69000 / 86400000 + 8 / 24;
        [, $m, $d] = civil_from_days((int)floor($days));
        $map["$m-$d"] = SOLAR_TERMS[$i];
    }
    return $cache[$y] = $map;
}

/* ---------- 國定假日（off）與通用節日（fest） ---------- */

function holidays_of(int $n, array $lu, string $term): array
{
    [$y, $m, $d] = civil_from_days($n);
    $out = [];
    $add = function ($name, $short, $type) use (&$out) {
        $out[] = ['n' => $name, 's' => $short, 't' => $type];
    };
    $eff = $y * 10000 + $m * 100 + $d >= 20250531;
    $dow = weekday_of($n);
    $k = "$m-$d";
    $solar = [
        '1-1' => ['中華民國開國紀念日', '元旦', 'off'], '2-14' => ['情人節', '情人節', 'fest'], '2-28' => ['和平紀念日', '和平紀念', 'off'],
        '3-8' => ['婦女節', '婦女節', 'fest'], '3-12' => ['植樹節', '植樹節', 'fest'], '3-29' => ['青年節', '青年節', 'fest'], '4-4' => ['兒童節', '兒童節', 'off'],
        '5-1' => ['勞動節', '勞動節', $eff ? 'off' : 'fest'], '8-8' => ['父親節', '父親節', 'fest'], '9-28' => ['孔子誕辰紀念日（教師節）', '教師節', $eff ? 'off' : 'fest'],
        '10-10' => ['國慶日', '國慶日', 'off'], '10-25' => ['臺灣光復暨金門古寧頭大捷紀念日', '光復節', $eff ? 'off' : 'fest'],
        '12-25' => ['行憲紀念日', '行憲紀念', $eff ? 'off' : 'fest'],
    ];
    if (isset($solar[$k])) $add(...$solar[$k]);
    if ($term === '清明') $add('民族掃墓節（清明節）', '清明節', 'off');
    if (!$lu['leap']) {
        $lk = $lu['m'] . '-' . $lu['d'];
        $lmap = [
            '1-1' => ['春節（正月初一）', '春節', 'off'], '1-2' => ['春節（正月初二）', '春節', 'off'], '1-3' => ['春節（正月初三）', '春節', 'off'],
            '1-15' => ['元宵節', '元宵節', 'fest'], '5-5' => ['端午節', '端午節', 'off'], '7-7' => ['七夕', '七夕', 'fest'], '7-15' => ['中元節', '中元節', 'fest'],
            '8-15' => ['中秋節', '中秋節', 'off'], '9-9' => ['重陽節', '重陽節', 'fest'], '12-8' => ['臘八節', '臘八', 'fest'], '12-16' => ['尾牙', '尾牙', 'fest'],
        ];
        if (isset($lmap[$lk])) $add(...$lmap[$lk]);
    }
    $n1 = lunar_of($n + 1);
    $n2 = lunar_of($n + 2);
    if ($n1['m'] === 1 && $n1['d'] === 1 && !$n1['leap']) $add('除夕', '除夕', 'off');
    if ($n2['m'] === 1 && $n2['d'] === 1 && !$n2['leap']) $add('小年夜（除夕前一日）', '小年夜', $eff ? 'off' : 'fest');
    if ($m === 5 && $dow === 0 && $d >= 8 && $d <= 14) $add('母親節', '母親節', 'fest');
    if ($k === '12-25') $add('聖誕節', '聖誕節', 'fest');
    return $out;
}

function term_of(int $n): string
{
    [$y, $m, $d] = civil_from_days($n);
    return solar_terms($y)["$m-$d"] ?? '';
}

function short_holiday_name(string $name): string
{
    $map = load_json_data('holiday_short_names.json');
    if (isset($map[$name])) return $map[$name];
    $chars = preg_split('//u', $name, -1, PREG_SPLIT_NO_EMPTY);
    return count($chars) > 4 ? implode('', array_slice($chars, 0, 4)) : $name;
}

/** 未公告年份：國定假日遇週六於前一日補假、遇週日於後一日補假（推算） */
function rule_year(int $y): array
{
    static $cache = [];
    if (isset($cache[$y])) return $cache[$y];
    $map = [];
    $end = days_from_civil($y + 1, 1, 1);
    for ($n = days_from_civil($y, 1, 1); $n < $end; $n++) {
        [, $m, $d] = civil_from_days($n);
        $offs = array_values(array_filter(holidays_of($n, lunar_of($n), term_of($n)), fn($h) => $h['t'] === 'off'));
        if (!$offs) continue;
        $k = pad2($m) . pad2($d);
        $map[$k] = array_merge($map[$k] ?? [], array_column($offs, 'n'));
        $dow = weekday_of($n);
        if ($dow === 6 || $dow === 0) {
            $s = $n;
            do {
                $s += $dow === 6 ? -1 : 1;
                [, $sm, $sd] = civil_from_days($s);
                $sw = weekday_of($s);
            } while ($sw === 0 || $sw === 6 || isset($map[pad2($sm) . pad2($sd)]));
            [$sy] = civil_from_days($s);
            if ($sy === $y) {
                $sk = pad2($sm) . pad2($sd);
                $map[$sk] = array_merge($map[$sk] ?? [], ['補假（推算）']);
            }
        }
    }
    return $cache[$y] = $map;
}

/** 這天放不放假：2017–2027 年用人事行政總處的辦公日曆表，其他年份依規則推算 */
function day_status(int $n): array
{
    [$y, $m, $d] = civil_from_days($n);
    $dow = weekday_of($n);
    $we = $dow === 0 || $dow === 6;
    $k = pad2($m) . pad2($d);
    $official = load_json_data('official_holidays.json');
    if (isset($official[(string)$y])) {
        $r = $official[(string)$y][$k] ?? null;
        if (!$r) return ['off' => $we, 'work' => false, 'names' => [], 'src' => 'official'];
        return $r[0] === 'h'
            ? ['off' => true, 'work' => false, 'names' => $r[1] !== '' ? [$r[1]] : [], 'src' => 'official']
            : ['off' => false, 'work' => true, 'names' => [], 'src' => 'official'];
    }
    $names = rule_year($y)[$k] ?? [];
    return ['off' => $we || count($names) > 0, 'work' => false, 'names' => $names, 'src' => 'rule'];
}

/** 連假：連續 3 天以上放假、且包含國定假日或補假 */
function long_weekend_of(int $n): ?array
{
    static $cache = [];
    if (array_key_exists($n, $cache)) return $cache[$n];
    if (!day_status($n)['off']) return $cache[$n] = null;
    $s = $n;
    $e = $n;
    for ($i = 0; $i < 20 && day_status($s - 1)['off']; $i++) $s--;
    for ($i = 0; $i < 20 && day_status($e + 1)['off']; $i++) $e++;
    $len = $e - $s + 1;
    $run = null;
    if ($len >= 3) {
        $names = [];
        for ($t = $s; $t <= $e; $t++) $names = array_merge($names, day_status($t)['names']);
        if ($names) {
            $spring = array_filter($names, fn($x) => preg_match('/春節|除夕|小年夜/u', $x));
            if ($spring) {
                $main = '春節';
            } else {
                $pick = null;
                foreach ($names as $x) {
                    if (!preg_match('/補假|調整/u', $x)) { $pick = $x; break; }
                }
                $main = short_holiday_name($pick ?? $names[0]);
            }
            $run = ['start' => ymd_of($s), 'end' => ymd_of($e), 'len' => $len,
                'name' => preg_replace('/紀念$/u', '紀念日', $main) . '連假'];
        }
    }
    return $cache[$n] = $run;
}

/** 一天的完整資訊 */
function day_info(int $n): array
{
    $lu = lunar_of($n);
    $term = term_of($n);
    $fests = array_values(array_filter(holidays_of($n, $lu, $term), fn($h) => $h['t'] === 'fest'));
    $st = day_status($n);
    $offNames = $st['names'];
    if ($offNames) {
        $sp = ['s' => short_holiday_name(str_replace('（推算）', '', $offNames[0])), 't' => 'off'];
    } elseif ($st['work']) {
        $sp = ['s' => '補班', 't' => 'mk'];
    } elseif ($fests) {
        $sp = ['s' => $fests[0]['s'], 't' => 'fest'];
    } elseif ($term !== '') {
        $sp = ['s' => $term, 't' => 'term'];
    } else {
        $sp = null;
    }
    return [
        'lu' => $lu, 'term' => $term, 'fests' => $fests, 'offNames' => $offNames, 'status' => $st, 'sp' => $sp,
        'off' => $st['off'] && count($offNames) > 0, 'run' => long_weekend_of($n),
    ];
}
