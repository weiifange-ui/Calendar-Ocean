台灣海鮮萬年曆（PHP 版） v3.0.3
================================

在自己電腦用 XAMPP 測試
-----------------------
1. 安裝 XAMPP（PHP 8.0 以上），打開 XAMPP Control Panel，按 Apache 的 Start。
2. 把整個 calendar-ocean 資料夾放進 XAMPP 的 htdocs，例如：
     Windows：C:\xampp\htdocs\calendar-ocean
     macOS ：/Applications/XAMPP/htdocs/calendar-ocean
3. 用瀏覽器開啟 http://localhost/calendar-ocean/
   （不要直接雙擊 index.php，那樣 PHP 不會執行）

不需要資料庫，也不需要另外開啟任何 PHP 擴充功能。

檔案說明
--------
config.php        版本號與設定。要改版本號，只要改這裡的 APP_VERSION、APP_RELEASE_DATE、APP_RELEASE_NOTE，
                  並在 APP_CHANGELOG 最上面加一筆。頁面底部的版本文字、CSS／JS 的快取參數都會跟著變。
index.php         頁面（外觀）。
api.php           資料介面：每月日曆、農曆、節氣、放假、行程、紀念日、每日學習。
lib/calendar.php  農曆、二十四節氣、國定假日、補假、連假的計算。
lib/planner.php   行程與紀念日的讀寫。
assets/app.css    樣式。
assets/app.js     畫面與動畫，資料都向 api.php 要。
data/             資料檔：
  seafood.json             當令海鮮清單
  official_holidays.json   行政院人事行政總處 2017–2027 年辦公日曆表
  holiday_short_names.json 節日簡稱
  learn.json               每日學習的英文與程式碼題庫
  towns.json               鄉鎮天氣的縣市與鄉鎮清單
  lunar_table.json         農曆年表（1899–2100）
  planner.json             行程、紀念日、天氣地點（第一次新增時自動建立）

要增減海鮮、題庫、鄉鎮，直接改 data 裡的 JSON 檔即可，不用改程式。
data 資料夾必須可以寫入，行程與紀念日才存得進去。

注意
----
- GitHub Pages 不能執行 PHP，這個版本要放在支援 PHP 的主機上。
- 行程與紀念日存在伺服器上，任何能打開這個網址的人都看得到、也改得到。
  目前沒有登入功能，適合在自己電腦或家用網路裡使用。
