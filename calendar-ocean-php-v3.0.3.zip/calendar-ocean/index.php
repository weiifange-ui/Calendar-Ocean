<?php
/*
 * 台灣海鮮萬年曆：頁面
 * 這個檔案只負責外觀（版面、插畫、動畫）。萬年曆的資料由 api.php 計算，版本號寫在 config.php。
 * 請用 XAMPP 之類有 PHP 的伺服器開啟，例如 http://localhost/calendar-ocean/
 */
require __DIR__ . '/config.php';
require __DIR__ . '/lib/calendar.php';
require __DIR__ . '/lib/planner.php';

function h(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

/* 第一次打開時，直接把這個月的資料一起放進頁面，不用等第二次請求 */
$now = new DateTimeImmutable('now', new DateTimeZone('Asia/Taipei'));
$today = ['y' => (int)$now->format('Y'), 'm' => (int)$now->format('n'), 'd' => (int)$now->format('j')];
$bootError = null;
try {
    $planner = planner_read();
    $month = month_payload($today['y'], $today['m'], $planner);
} catch (Throwable $e) {
    $planner = planner_empty();
    $month = null;
    $bootError = $e->getMessage();
}
$boot = [
    'version' => version_info(),
    'today' => $today,
    'seafood' => array_map(fn($f) => [$f['name'], $f['place'], $f['months'], $f['type'], $f['eat']], load_json_data('seafood.json')),
    'towns' => load_json_data('towns.json'),
    'town' => $planner['town'] ?? null,
    'month' => $month,
    'error' => $bootError,
];
header('Content-Type: text/html; charset=utf-8');
?><!DOCTYPE html>
<html lang="zh-Hant-TW">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="app-version" content="<?= h(APP_VERSION) ?>">
<title><?= h(APP_NAME) ?></title>
<link rel="stylesheet" href="<?= h(asset_url('assets/app.css')) ?>">
</head>
<body>
<div class="bg" aria-hidden="true" id="bg"><canvas id="sea"></canvas></div>
<canvas id="fx" aria-hidden="true"></canvas>
<button type="button" class="sb-toggle" id="sbToggle" aria-controls="sidebar" aria-expanded="true"><span aria-hidden="true">☰</span><span>側邊欄</span></button>
<div class="sb-mask" id="sbMask" aria-hidden="true"></div>
<aside class="sidebar" id="sidebar" aria-label="側邊欄">
<div class="sb-top">
<div class="sb-head"><span class="sb-date" id="sbDate"></span><button type="button" class="sb-close" id="sbClose" aria-label="收合側邊欄">收合 ›</button></div>
<nav class="sb-nav" id="sbNav" aria-label="跳到側邊欄區塊"><button type="button" data-go="planCard">行程</button><button type="button" data-go="annCard">紀念日</button><button type="button" data-go="learnCard">每日學習</button><button type="button" data-go="wxCard">鄉鎮天氣</button><button type="button" data-go="yearCard">全年產季</button></nav>
</div>
<section class="card side-card" id="planCard">
<h2 id="planTitle">行程</h2>
<div id="evBox"></div>
</section>
<section class="card side-card" id="annCard">
<h2 id="annTitle">紀念日</h2>
<div id="anBox"></div>
<p class="sync" id="syncNote"></p>
</section>
<section class="card side-card" id="learnCard">
<h2 id="learnTitle">每日學習</h2>
<div class="tabs" role="group" aria-label="學習類別"><button type="button" data-tab="en" aria-pressed="true">英文</button><button type="button" data-tab="code" aria-pressed="false">程式碼</button></div>
<p class="learn-date" id="learnDate"></p>
<div class="learn-body" id="learnBody" aria-live="polite"></div>
</section>
<section class="card side-card" id="wxCard">
<h2 id="wxTitle">鄉鎮天氣</h2>
<div class="wx-row"><label>縣市<select id="wxCounty"></select></label><label>鄉鎮市區<select id="wxTown"></select></label></div>
<a class="wx-go" id="wxGo" href="https://www.cwa.gov.tw/V8/C/W/Town/Town.html" target="_blank" rel="noopener noreferrer">查看天氣預報 ↗</a>
<p class="wx-note">資料來源為交通部中央氣象署鄉鎮預報。這個網頁基於安全限制無法直接連線到外部氣象服務，所以會在新分頁開啟官方的鄉鎮預報頁面。你選的鄉鎮會被記住。</p>
</section>
<section class="card side-card year-card" id="yearCard">
<h2 id="yearTitle">全年產季</h2>
<div class="legend"><span><i style="background:rgba(134,214,189,.5)"></i>適合生食</span><span><i style="background:rgba(241,179,127,.5)"></i>適合熟食</span></div>
<div class="scroll"><div class="year" id="year"></div></div>
<p class="note">產季為大約範圍，每年會因水溫與海況前後移動，出發前可先問產地漁港。</p>
</section>
</aside>
<button type="button" class="trail-btn" id="trailBtn" aria-pressed="true"><span class="sw" aria-hidden="true"></span><span>浪花軌跡</span></button>
<svg width="0" height="0" style="position:absolute" aria-hidden="true"><filter id="brush" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency="0.09" numOctaves="2" seed="4"></feTurbulence><feDisplacementMap in="SourceGraphic" scale="2.2"></feDisplacementMap></filter></svg>
<div class="page">
<header>
<h1>台灣海鮮萬年曆</h1>
<p class="sub">跟著黑潮，吃當令的海</p>
</header>
<div class="yearbar"><button type="button" id="prevY" aria-label="上一年">‹</button><span class="y" id="yLabel"></span><button type="button" id="nextY" aria-label="下一年">›</button><button type="button" class="today-btn" id="goToday">回到今天</button></div>
<nav class="months" id="months" aria-label="選擇月份"></nav>
<section class="card cal-card" id="calCard">
<h2 id="calTitle"><svg class="lh" viewBox="0 0 60 90" aria-hidden="true">
<circle class="lh-glow" cx="31" cy="19" r="12" fill="rgba(255,190,110,.42)"></circle>
<g filter="url(#boatMask)">
<path d="M3,88 C9,77 21,74 30,76 C41,72 53,76 59,88Z" fill="#6f6a5e"></path>
<path d="M21,76 L24,34 L38,34 L41,76Z" fill="#cfc6b4"></path>
<path d="M20,34 L42,34 L40.5,30.5 L21.5,30.5Z" fill="#8f8676"></path>
<path d="M20,31 L20,25.5 L23.4,25.5 L23.4,28 L27.1,28 L27.1,25.5 L30.5,25.5 L30.5,28 L34.2,28 L34.2,25.5 L37.6,25.5 L37.6,28 L41.3,28 L41.3,25.5 L42,25.5 L42,31Z" fill="#cfc6b4"></path>
<path d="M29.4,50 L29.4,45.5 Q31,43.4 32.6,45.5 L32.6,50Z M29.6,63 L29.6,58.8 Q31,56.9 32.4,58.8 L32.4,63Z" fill="#3d4b57"></path>
<path d="M28.6,76 L28.6,70.4 Q31,67.6 33.4,70.4 L33.4,76Z" fill="#7a5236"></path>
</g>
<g class="lh-fire">
<path d="M26.5,26.5 C25.4,21.6 28.3,20.2 27.6,15.6 C30.3,17.4 29.6,12.5 31.6,9 C32.8,14 36.4,15 35.2,19.4 C37.2,18.6 37.6,22.6 35.6,26.5Z" fill="#e8873a"></path>
<path d="M28.6,26.5 C28.1,23.2 30.2,22.2 29.9,19 C31.6,20.4 31.6,17.4 32.6,15.2 C33.4,18.6 35,20 33.9,26.5Z" fill="#f6d58e"></path>
</g>
<g filter="url(#brush)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round">
<path d="M21,76 L24,34 L38,34 L41,76" stroke-width="1.5" opacity=".95"></path>
<path d="M20,34 L42,34 L40.5,30.5 L21.5,30.5Z" stroke-width="1" opacity=".85"></path>
<path d="M20,31 L20,25.5 L23.4,25.5 L23.4,28 L27.1,28 L27.1,25.5 L30.5,25.5 L30.5,28 L34.2,28 L34.2,25.5 L37.6,25.5 L37.6,28 L41.3,28 L41.3,25.5 L42,25.5 L42,31" stroke-width="1.1" opacity=".9"></path>
<path d="M23.6,41 L38.4,41 M23.1,48 L38.9,48 M22.6,55 L39.4,55 M22.1,62 L39.9,62 M21.6,69 L40.4,69 M27,34 L27,41 M35,34 L35,41 M26,41 L26,48 M36,41 L36,48 M27.5,48 L27.5,55 M34.5,48 L34.5,55 M25.5,55 L25.5,62 M36.5,55 L36.5,62 M27,62 L27,69 M35,62 L35,69 M25,69 L25,76 M37,69 L37,76" stroke-width=".7" opacity=".5"></path>
<path d="M29.4,50 L29.4,45.5 Q31,43.4 32.6,45.5 L32.6,50 M29.6,63 L29.6,58.8 Q31,56.9 32.4,58.8 L32.4,63" stroke-width=".8" opacity=".8"></path>
<path d="M28.6,76 L28.6,70.4 Q31,67.6 33.4,70.4 L33.4,76" stroke-width=".9" opacity=".85"></path>
<path d="M3,88 C9,77 21,74 30,76 C41,72 53,76 59,88" stroke-width="1.4" opacity=".85"></path>
<path d="M14,84 q4,-3 8,0 M40,83 q4,-3 8,0" stroke-width="1" opacity=".7"></path>
</g>
</svg><span id="calTitleText"></span></h2>
<div class="cal-head"><p class="cal-sub" id="calSub"></p><div class="mnav"><button type="button" id="prevM" aria-label="上個月">‹ 上個月</button><button type="button" id="nextM" aria-label="下個月">下個月 ›</button></div></div>
<div class="wk" aria-hidden="true"><div class="we">日</div><div>一</div><div>二</div><div>三</div><div>四</div><div>五</div><div class="we">六</div></div>
<div class="days" id="days"></div>
<div class="legend" style="margin:14px 0 0"><span><i style="background:#ffa48f"></i>國定假日</span><span><i style="background:#f6d58e"></i>節日</span><span><i style="background:#9fe3cc"></i>節氣</span><span><i style="background:#c3c9ff"></i>補行上班</span><span><i style="background:rgba(255,164,143,.35)"></i>連假</span></div>
<div class="detail" id="detail" aria-live="polite"></div>
<p class="note">2017 至 2027 年的國定假日、補假、彈性放假與補行上班，依行政院人事行政總處公布的政府行政機關辦公日曆表標示；其他年份依《紀念日及節日實施條例》推算。辦公日曆表適用於公務人員，民間企業的放假依勞動部規定。</p>
<div class="boat" id="boat" aria-hidden="true"><svg viewBox="0 0 300 170" role="img" aria-label="在浪濤中航行的三桅全帆裝帆船">
<filter id="boatMask" x="-10%" y="-10%" width="120%" height="120%"><feTurbulence type="fractalNoise" baseFrequency="0.035" numOctaves="2" seed="77" result="n"></feTurbulence><feColorMatrix in="n" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0" result="na"></feColorMatrix><feComponentTransfer in="na" result="m"><feFuncA type="linear" slope="14" intercept="-3.7"></feFuncA></feComponentTransfer><feComposite in="SourceGraphic" in2="m" operator="in" result="c"></feComposite><feOffset in="c" dx="1.2" dy="0.8"></feOffset></filter>
<defs><linearGradient id="gBack" gradientUnits="userSpaceOnUse" x1="0" y1="96" x2="0" y2="168"><stop offset="0" stop-color="#78aacd" stop-opacity=".5"></stop><stop offset="1" stop-color="#78aacd" stop-opacity="0"></stop></linearGradient><linearGradient id="gMid" gradientUnits="userSpaceOnUse" x1="0" y1="104" x2="0" y2="168"><stop offset="0" stop-color="#5f96c0" stop-opacity=".6"></stop><stop offset="1" stop-color="#5f96c0" stop-opacity="0"></stop></linearGradient><linearGradient id="gFront" gradientUnits="userSpaceOnUse" x1="0" y1="112" x2="0" y2="168"><stop offset="0" stop-color="#467daa" stop-opacity=".65"></stop><stop offset="1" stop-color="#467daa" stop-opacity="0"></stop></linearGradient><linearGradient id="seaFadeG" x1="0" x2="1" y1="0" y2="0"><stop offset="0" stop-color="#fff" stop-opacity="0"></stop><stop offset=".14" stop-color="#fff"></stop><stop offset=".86" stop-color="#fff"></stop><stop offset="1" stop-color="#fff" stop-opacity="0"></stop></linearGradient>
<mask id="seaFade" maskUnits="userSpaceOnUse" x="-40" y="-40" width="460" height="260"><rect x="-20" y="-40" width="410" height="260" fill="url(#seaFadeG)"></rect></mask></defs>
<g mask="url(#seaFade)">
<path id="wBack" fill="url(#gBack)"></path>
<path id="cBack" fill="none" stroke="#fff" stroke-width="1.1" stroke-opacity=".45" stroke-linecap="round" filter="url(#brush)"></path>
<path id="wMid" fill="url(#gMid)"></path>
<path id="cMid" fill="none" stroke="#fff" stroke-width="1.5" stroke-opacity=".7" stroke-linecap="round" filter="url(#brush)"></path>
<g id="foamMid" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1.3"></g>
</g>
<g id="boatG">
<g transform="translate(145 119) scale(.9) translate(-145 -119)">
<filter id="sailMask" x="-10%" y="-10%" width="120%" height="120%"><feTurbulence type="fractalNoise" baseFrequency="0.035" numOctaves="2" seed="77" result="n"></feTurbulence><feColorMatrix in="n" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0" result="na"></feColorMatrix><feComponentTransfer in="na" result="m"><feFuncA type="linear" slope="14" intercept="-1.6"></feFuncA></feComponentTransfer><feComposite in="SourceGraphic" in2="m" operator="in" result="c"></feComposite><feOffset in="c" dx="1.2" dy="0.8"></feOffset></filter>
<g filter="url(#sailMask)">
<path d="M58,52 L98,52 Q93,63.0 98,74 Q75.5,78 58,74 Q50.0,63.0 58,52Z M62,30 L94,30 Q90,39.0 94,48 Q76.0,51 62,48 Q55.6,39.0 62,30Z M66,14 L90,14 Q87,20.5 90,27 Q76.5,29 66,27 Q61.2,20.5 66,14Z M114,50 L166,50 Q160,64.0 166,78 Q137.0,82 114,78 Q104.4,64.0 114,50Z M119,26 L161,26 Q156,36.0 161,46 Q137.5,49 119,46 Q111.0,36.0 119,26Z M124,6 L156,6 Q153,14.0 156,22 Q138.5,24 124,22 Q119.2,14.0 124,6Z M184,36 L216,36 Q212,45.0 216,54 Q198.0,57 184,54 Q177.6,45.0 184,36Z M188,20 L212,20 Q209,26.0 212,32 Q198.5,34 188,32 Q183.2,26.0 188,20Z" fill="#f2ead6"></path>
<path d="M76,14 Q38,40 -12,68 L22,82 Q48,50 76,14Z M77,34 Q50,58 14,80 L44,88 Q60,62 77,34Z M140,30 Q112,44 98,60 L112,72 Q122,52 140,30Z M203,58 L242,64 Q250,76 248,92 L204,88 Q208,72 203,58Z" fill="#ece2c9"></path>
<path d="M78,8 L64,11 L78,14Z M140,-6 L122,-2.5 L140,1Z M200,14 L188,17 L200,20Z" fill="#c0503f"></path>
<path d="M266.5,61 Q260,58.5 254,62 L254,73 Q260,69.5 265.2,72Z" fill="#c0503f"></path>
<path d="M22,86 L196,90 L200,83 L263,79 L261,96 C255,110 238,118 214,119 L70,119 C46,118 31,107 22,86Z" fill="#b47b45"></path>
<path d="M24,91 C70,98 150,99 262,91 L261,95 C150,104 70,103 26,96Z M30,103 C70,110 160,110 256,102 L254,106 C160,115 70,114 33,107Z" fill="#6b4a32"></path>
<path d="M56,92.5 h5 v3.5 h-5Z M74,93.2 h5 v3.5 h-5Z M92,93.7 h5 v3.5 h-5Z M110,94.1 h5 v3.5 h-5Z M128,94.4 h5 v3.5 h-5Z M146,94.6 h5 v3.5 h-5Z M164,94.6 h5 v3.5 h-5Z M182,94.4 h5 v3.5 h-5Z M200,93.8 h5 v3.5 h-5Z M218,92.9 h5 v3.5 h-5Z" fill="#3a2718"></path>
<path d="M236,84 h5 v4 h-5Z M244,83.4 h5 v4 h-5Z M252,82.8 h5 v4 h-5Z" fill="#f6d58e"></path>
</g>
<g filter="url(#brush)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round">
<path d="M78,90 L78,6 M140,93 L140,-8 M200,86 L200,12" stroke-width="1.8" opacity=".95"></path>
<path d="M24,86 L-16,64" stroke-width="1.6" opacity=".9"></path>
<path d="M262,80 L267,59" stroke-width="1" opacity=".85"></path>
<path d="M54,52 L102,52 M58,30 L98,30 M63,14 L93,14 M110,50 L170,50 M115,26 L165,26 M121,6 L159,6 M180,36 L220,36 M185,20 L215,20 M203,58 L244,62 M204,88 L250,92" stroke-width="1.3" opacity=".9"></path>
<path d="M58,52 L98,52 Q93,63.0 98,74 Q75.5,78 58,74 Q50.0,63.0 58,52Z M62,30 L94,30 Q90,39.0 94,48 Q76.0,51 62,48 Q55.6,39.0 62,30Z M66,14 L90,14 Q87,20.5 90,27 Q76.5,29 66,27 Q61.2,20.5 66,14Z M114,50 L166,50 Q160,64.0 166,78 Q137.0,82 114,78 Q104.4,64.0 114,50Z M119,26 L161,26 Q156,36.0 161,46 Q137.5,49 119,46 Q111.0,36.0 119,26Z M124,6 L156,6 Q153,14.0 156,22 Q138.5,24 124,22 Q119.2,14.0 124,6Z M184,36 L216,36 Q212,45.0 216,54 Q198.0,57 184,54 Q177.6,45.0 184,36Z M188,20 L212,20 Q209,26.0 212,32 Q198.5,34 188,32 Q183.2,26.0 188,20Z" stroke-width="1" opacity=".8"></path>
<path d="M76,14 Q38,40 -12,68 L22,82 Q48,50 76,14Z M77,34 Q50,58 14,80 L44,88 Q60,62 77,34Z M140,30 Q112,44 98,60 L112,72 Q122,52 140,30Z M203,58 L242,64 Q250,76 248,92 L204,88 Q208,72 203,58Z" stroke-width=".9" opacity=".75"></path>
<path d="M68.0,53 Q60.0,63.0 68.0,76.4 M78.0,53 Q70.0,63.0 78.0,76.4 M88.0,53 Q80.0,63.0 88.0,76.4 M70.0,31 Q63.6,39.0 70.0,49.8 M78.0,31 Q71.6,39.0 78.0,49.8 M86.0,31 Q79.6,39.0 86.0,49.8 M72.0,15 Q67.2,20.5 72.0,28.2 M78.0,15 Q73.2,20.5 78.0,28.2 M84.0,15 Q79.2,20.5 84.0,28.2 M127.0,51 Q117.4,64.0 127.0,80.4 M140.0,51 Q130.4,64.0 140.0,80.4 M153.0,51 Q143.4,64.0 153.0,80.4 M129.5,27 Q121.5,36.0 129.5,47.8 M140.0,27 Q132.0,36.0 140.0,47.8 M150.5,27 Q142.5,36.0 150.5,47.8 M132.0,7 Q127.2,14.0 132.0,23.2 M140.0,7 Q135.2,14.0 140.0,23.2 M148.0,7 Q143.2,14.0 148.0,23.2 M192.0,37 Q185.6,45.0 192.0,55.8 M200.0,37 Q193.6,45.0 200.0,55.8 M208.0,37 Q201.6,45.0 208.0,55.8 M194.0,21 Q189.2,26.0 194.0,33.2 M200.0,21 Q195.2,26.0 200.0,33.2 M206.0,21 Q201.2,26.0 206.0,33.2" stroke-width=".5" opacity=".45"></path>
<path d="M-16,64 L78,8 M-6,70 L78,30 M78,8 L140,-6 M78,30 L140,26 M140,-6 L200,14 M140,26 L200,36 M200,14 L263,79 M78,10 L52,88 M78,10 L104,91 M140,-4 L112,91 M140,-4 L170,92 M200,16 L186,88 M200,16 L232,84 M78,30 L60,88 M140,26 L120,91 M200,36 L192,88" stroke-width=".55" opacity=".5"></path>
<path d="M22,86 L196,90 L200,83 L263,79" stroke-width="1.4" opacity=".9"></path>
<path d="M22,82.5 L196,86.5 M200,79.5 L263,75.5 M40,83 L40,86.5 M60,83.5 L60,87 M80,84 L80,87.5 M100,84.5 L100,88 M120,85 L120,88.5 M160,86 L160,89.5 M180,86.4 L180,90 M215,78.5 L215,82 M230,77.6 L230,81 M245,76.6 L245,80" stroke-width=".8" opacity=".7"></path>
<path d="M22,86 L196,90 L200,83 L263,79 L261,96 C255,110 238,118 214,119 L70,119 C46,118 31,107 22,86Z" stroke-width="2.2" opacity=".95"></path>
<path d="M14,80 Q18,86 24,88" stroke="#d8b65a" stroke-width="1.6" opacity=".9"></path>
<path d="M261,83 L261,96" stroke-width="1" opacity=".7"></path>
</g>
</g>
</g>

<g mask="url(#seaFade)">
<path id="bowFoam" fill="rgba(255,255,255,.85)"></path>
<path id="wFront" fill="url(#gFront)"></path>
<path id="cFront" fill="none" stroke="#fff" stroke-width="2" stroke-opacity=".9" stroke-linecap="round" filter="url(#brush)"></path>
<g id="foamFront" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1.5"></g>
</g>
<g id="lines" fill="none" stroke="#fff" stroke-linecap="round"></g>
<g id="spray" fill="#fff" stroke="#fff" stroke-linecap="round"></g>
</svg></div>
</section>
<p class="now" id="now"></p>
<p class="hint" id="hint"></p>
<section class="catch" id="catch" aria-live="polite"></section>

<p class="version"><?= h(version_line()) ?></p>
</div>
<script>window.BOOT=<?= json_encode($boot, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
<script src="<?= h(asset_url('assets/app.js')) ?>"></script>
</body>
</html>
