<?php
/*
 * 台灣海鮮萬年曆：設定檔
 * ─────────────────────────────────────────────
 * 版本號只要改這裡。頁面底部的版本文字、CSS／JS 的快取參數（?v=…）、
 * 以及 api.php 回傳的版本資訊，全部都讀這幾個值。
 */

const APP_NAME = '台灣海鮮萬年曆';
const APP_VERSION = '3.0.3';
const APP_RELEASE_DATE = '2026-11-16';
const APP_RELEASE_NOTE = '月曆格子底部加高，帆船不再蓋到格子裡的字';

/* 版本紀錄（新的寫在最上面）。頁面會顯示第一筆。 */
const APP_CHANGELOG = [
    ['3.0.3', '2026-11-16', APP_RELEASE_NOTE],
    ['3.0.2', '2026-11-16', '修正帆的方向，帆面順風往船頭鼓起，旗子往船頭飄'],
    ['3.0.1', '2026-11-16', '帆船改成三桅全帆裝帆船（每根桅三層方帆，船首有三角帆）'],
    ['3.0.0', '2026-11-16', '改由 PHP 控制萬年曆：農曆、節氣、放假日、每日學習都由伺服器計算，行程與紀念日存在伺服器上；燈塔與船改成中古世紀風格'],
    ['2.34', '2026-11-16', '燈塔改成中古世紀石造燈塔，漁船改成三桅帆船'],
    ['2.33', '2026-11-14', '修正卡片手繪外框擋住點擊，側邊欄與月曆恢復可以操作'],
    ['2.32', '2026-11-14', '手機側邊欄加上遮罩與右滑收合；手機點擊時也會出現海星游標與浪花'],
    ['2.31', '2026-11-14', '游標換成海星'],
];

/* 資料夾位置：data 資料夾要能寫入，行程與紀念日會存在 data/planner.json */
define('DATA_DIR', __DIR__ . '/data');

/* 「今天」以台灣時間為準 */
date_default_timezone_set('Asia/Taipei');

/** 給 CSS／JS 網址用的快取參數：版本號改了，瀏覽器就會重新下載 */
function asset_url(string $path): string
{
    $file = __DIR__ . '/' . $path;
    $stamp = is_file($file) ? filemtime($file) : 0;
    return $path . '?v=' . rawurlencode(APP_VERSION) . '.' . $stamp;
}

function version_info(): array
{
    return ['name' => APP_NAME, 'version' => APP_VERSION, 'date' => APP_RELEASE_DATE, 'note' => APP_RELEASE_NOTE];
}

/** 頁面底部顯示的版本文字，例如「台灣海鮮萬年曆　v3.0.0｜2026.11.16 更新：…」 */
function version_line(): string
{
    return APP_NAME . '　v' . APP_VERSION . '｜' . str_replace('-', '.', APP_RELEASE_DATE) . ' 更新：' . APP_RELEASE_NOTE;
}
