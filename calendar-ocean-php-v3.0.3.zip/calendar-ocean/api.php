<?php
/*
 * 萬年曆的資料介面。頁面只負責外觀，資料都從這裡拿。
 *
 * GET  api.php?action=version                     版本資訊
 * GET  api.php?action=month&y=2026&m=11           某個月的日曆、農曆、節氣、放假、行程、紀念日、每日學習
 * POST api.php?action=event_add     {y,m,d,time,title}
 * POST api.php?action=event_remove  {id,y,m}
 * POST api.php?action=anniv_add     {y,m,d,title,year,lunar}
 * POST api.php?action=anniv_remove  {id,y,m}
 * POST api.php?action=town          {town}
 * 新增、刪除之後會直接回傳更新過的那個月，頁面不用再多問一次。
 */

require __DIR__ . '/config.php';
require __DIR__ . '/lib/calendar.php';
require __DIR__ . '/lib/planner.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-App-Version: ' . APP_VERSION);

function reply(array $data, int $code = 200): void
{
    http_response_code($code);
    echo json_encode(['ok' => $code < 400, 'version' => APP_VERSION] + $data, JSON_UNESCAPED_UNICODE);
    exit;
}

function fail(string $msg, int $code = 400): void
{
    reply(['error' => $msg], $code);
}

function int_param(array $src, string $key, int $min, int $max): int
{
    $v = filter_var($src[$key] ?? null, FILTER_VALIDATE_INT);
    if ($v === false || $v < $min || $v > $max) fail("參數 $key 不正確");
    return $v;
}

function text_param(array $src, string $key, int $maxChars, bool $required = true): string
{
    $v = trim((string)($src[$key] ?? ''));
    $v = preg_replace('/[\x00-\x1F\x7F]/u', '', $v);
    if ($v === null) fail("參數 $key 不是有效的文字");
    $chars = preg_split('//u', $v, -1, PREG_SPLIT_NO_EMPTY);
    if (count($chars) > $maxChars) $v = implode('', array_slice($chars, 0, $maxChars));
    if ($required && $v === '') fail("請填寫 $key");
    return $v;
}

function ym_from(array $src): array
{
    return [int_param($src, 'y', CAL_MIN_YEAR, CAL_MAX_YEAR), int_param($src, 'm', 1, 12)];
}

try {
    $action = $_GET['action'] ?? '';
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if ($method === 'GET') {
        if ($action === 'version') reply(['info' => version_info(), 'changelog' => APP_CHANGELOG]);
        if ($action === 'month') {
            [$y, $m] = ym_from($_GET);
            reply(['month' => month_payload($y, $m)]);
        }
        fail('未知的動作', 404);
    }

    if ($method !== 'POST') fail('不支援這種請求', 405);
    $body = json_decode(file_get_contents('php://input') ?: '', true);
    if (!is_array($body)) fail('請用 JSON 傳送資料');

    switch ($action) {
        case 'event_add': {
            [$y, $m] = ym_from($body);
            $d = int_param($body, 'd', 1, days_in_month($y, $m));
            $title = text_param($body, 'title', 60);
            $time = (string)($body['time'] ?? '');
            if ($time !== '' && !preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $time)) fail('時間格式不正確');
            $planner = planner_update(function ($p) use ($y, $m, $d, $time, $title) {
                $p['events'][] = ['id' => new_id(), 'date' => sprintf('%04d-%02d-%02d', $y, $m, $d), 'time' => $time, 'title' => $title];
                return $p;
            });
            reply(['month' => month_payload($y, $m, $planner)]);
        }
        case 'event_remove': {
            [$y, $m] = ym_from($body);
            $id = (string)($body['id'] ?? '');
            $planner = planner_update(function ($p) use ($id) {
                $p['events'] = array_values(array_filter($p['events'], fn($e) => $e['id'] !== $id));
                return $p;
            });
            reply(['month' => month_payload($y, $m, $planner)]);
        }
        case 'anniv_add': {
            [$y, $m] = ym_from($body);
            $d = int_param($body, 'd', 1, days_in_month($y, $m));
            $title = text_param($body, 'title', 40);
            $year = ($body['year'] ?? '') === '' || $body['year'] === null ? null : int_param($body, 'year', 1900, 2099);
            $isLunar = !empty($body['lunar']);
            if ($isLunar) {
                $lu = lunar_of(days_from_civil($y, $m, $d));
                $item = ['id' => new_id(), 'title' => $title, 'lunar' => true, 'm' => $lu['m'], 'd' => $lu['d'], 'year' => $year];
            } else {
                $item = ['id' => new_id(), 'title' => $title, 'lunar' => false, 'm' => $m, 'd' => $d, 'year' => $year];
            }
            $planner = planner_update(function ($p) use ($item) {
                $p['annivs'][] = $item;
                return $p;
            });
            reply(['month' => month_payload($y, $m, $planner)]);
        }
        case 'anniv_remove': {
            [$y, $m] = ym_from($body);
            $id = (string)($body['id'] ?? '');
            $planner = planner_update(function ($p) use ($id) {
                $p['annivs'] = array_values(array_filter($p['annivs'], fn($a) => $a['id'] !== $id));
                return $p;
            });
            reply(['month' => month_payload($y, $m, $planner)]);
        }
        case 'town': {
            $town = (string)($body['town'] ?? '');
            if (!preg_match('/^\d{7}$/', $town)) fail('鄉鎮代碼不正確');
            planner_update(function ($p) use ($town) {
                $p['town'] = $town;
                return $p;
            });
            reply(['town' => $town]);
        }
    }
    fail('未知的動作', 404);
} catch (Throwable $e) {
    fail('伺服器發生錯誤：' . $e->getMessage(), 500);
}
